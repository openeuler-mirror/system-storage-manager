:orphan:

.. note::
   See README for more information!

.. include:: src/install.rst
.. include:: src/requirements.rst

