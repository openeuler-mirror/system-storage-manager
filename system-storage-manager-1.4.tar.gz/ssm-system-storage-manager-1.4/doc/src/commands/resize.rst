Resize command
==============

.. include:: ../options/resize_usage.inc

.. include:: resize.txt

.. include:: ../options/resize_options.inc
