Snapshot command
================

.. include:: ../options/snapshot_usage.inc

.. include:: snapshot.txt

.. include:: ../options/snapshot_options.inc
