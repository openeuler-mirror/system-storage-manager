.. _add-command:

Add command
===========

.. include:: ../options/add_usage.inc

.. include:: add.txt

.. include:: ../options/add_options.inc
