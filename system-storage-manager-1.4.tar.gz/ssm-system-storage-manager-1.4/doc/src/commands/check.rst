Check command
=============

.. include:: ../options/check_usage.inc

.. include:: check.txt

.. include:: ../options/check_options.inc
