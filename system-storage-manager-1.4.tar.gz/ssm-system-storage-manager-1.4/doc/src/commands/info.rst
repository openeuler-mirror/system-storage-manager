Info command
============

.. include:: ../options/info_usage.inc

.. include:: info.txt

.. include:: ../options/info_options.inc