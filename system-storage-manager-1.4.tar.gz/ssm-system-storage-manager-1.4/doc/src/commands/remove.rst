Remove command
==============

.. include:: ../options/remove_usage.inc

.. include:: remove.txt

.. include:: ../options/remove_options.inc
