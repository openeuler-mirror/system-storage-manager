Introduction
============

System Storage Manager has several commands that you can specify on the
command line as a first argument to ssm. They all have a specific use and
their own arguments, but global ssm arguments are propagated to all commands.
