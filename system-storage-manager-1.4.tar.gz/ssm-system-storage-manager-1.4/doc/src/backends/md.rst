MD backend
=============

MD backend in **ssm** is currently limited to only gather the information
about MD volumes in the system. You can not create or manage MD volumes
or pools, but this functionality will be extended in the future.
