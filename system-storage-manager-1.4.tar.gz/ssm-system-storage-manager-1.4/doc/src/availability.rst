Availability
============

**System storage manager** is available from
http://system-storage-manager.github.io. You can subscribe to
storagemanager-devel@lists.sourceforge.net to follow the current development.
