:orphan:

System Storage Manager's documentation
======================================

.. genindex:
.. toctree::
    :maxdepth: 2


    src/synopsis
    src/description
    src/options/ssm_options
    src/commands/index
    src/backends/backends
    src/man_examples
    src/env_variables
    src/licence
    src/requirements
    src/availability

