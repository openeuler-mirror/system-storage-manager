Multipath backend
=============

Multipath backend in **ssm** is currently limited to only gather the
information about multipath volumes in the system. You can not create or
manage multipath volumes or pools, but this functionality will be extended in
the future.
