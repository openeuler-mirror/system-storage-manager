List command
============

.. include:: ../options/list_usage.inc

.. include:: list.txt

.. include:: ../options/list_options.inc
