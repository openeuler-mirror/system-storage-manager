Migrate command
===============

.. include:: ../options/migrate_usage.inc

.. include:: migrate.txt

.. include:: ../options/migrate_options.inc
